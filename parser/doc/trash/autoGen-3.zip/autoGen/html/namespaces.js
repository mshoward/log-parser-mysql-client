var namespaces =
[
    [ "hdparser", "namespacehdparser.html", null ],
    [ "parser_sqli", "namespaceparser__sqli.html", null ]
];
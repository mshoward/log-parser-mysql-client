var searchData=
[
  ['s_5fconfiguration',['s_configuration',['../structs__configuration.html',1,'']]]
];

var searchData=
[
  ['osversion',['osVersion',['../class_honey_d_log_statement.html#a2af12e462748f85d9fc75ef2ac2f564c',1,'HoneyDLogStatement::osVersion()'],['../classhdparser_1_1honeyd__parser.html#a15a9af45b4707534feb6d351d0c633b8',1,'hdparser::honeyd_parser::osVersion()']]]
];

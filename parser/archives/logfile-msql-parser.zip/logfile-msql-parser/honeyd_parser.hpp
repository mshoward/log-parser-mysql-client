


class honeyd_parser
{
	
	public:
	std::string currString;
	int index;
	enum WORDTYPE
	{
		TIMESTAMP,
		PACKETTYPE,
		SOURCEIP,
		SOURCESOCKET,
		TARGETIP,
		TARGETSOCKET,
		OSVERSION
	};
	
	honeyd_parser();
	honeyd_parser(std::string rawString);
	~honeyd_parser();
	void setString(std::string rawString)
	std::string getTimeStamp();
	std::string getPacketType();
	std::string getSourceIP();
	std::string getTargetIP();
	std::string getTargetSocket();
	std::string getOsVersion();
};

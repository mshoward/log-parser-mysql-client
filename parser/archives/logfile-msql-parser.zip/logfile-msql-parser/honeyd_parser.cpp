
honeyd_parser::honeyd_parser()
{
	currString = "";
}

honeyd_parser::honeyd_parser(std::string rawString)
{
	
}

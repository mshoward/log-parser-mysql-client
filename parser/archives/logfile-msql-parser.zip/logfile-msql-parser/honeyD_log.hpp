#ifndef HD_LOG_STATEMENT_H
#def HD_LOG_STATEMENT_H
	class HoneyDLogStatement
	{
		public:
		std::string timeStamp;
		std::string packetType;
		std::string sourceIP;
		std::string sourceSocket;
		std::string targetIP;
		std::string targetSocket;
		std::string osVersion;
		HoneyDLogStatement();
		~HoneyDLogStatement();
		HoneyDLogStatement(string rawLine);
		void populateFields(string rawLine);
		
	};
#endif
